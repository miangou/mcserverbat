!function($) {
  var UUID = require('uuid-v4');
  $.ender({
    UUID: UUID
  });
}(ender)