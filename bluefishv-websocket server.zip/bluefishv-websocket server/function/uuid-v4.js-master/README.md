# uuid-v4.js :: Random UUID (RFC-4122 v4) Generator

A lightning fast pure JS implementation of a Random UUID (RFC-4122 v4) Generator. Supports both client and server side JS implementations.